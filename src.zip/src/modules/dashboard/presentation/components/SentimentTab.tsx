import { cn } from '@/shared/lib/cn';
import { formatPercent, formatPersianNumber } from '@/shared/lib/format';
import { Panel } from '@/shared/ui';
import type { SentimentOverview } from '../../domain/analytics';
import { scopeForChart } from '../../domain/filters';
import { useDashboardFilterStore, useDashboardScope } from '../dashboardFilterStore';
import { useSentimentOverview } from '../hooks/analyticsQueries';
import { ChartState } from './ChartState';
import { CustomerSentimentFaces } from './SentimentFaces';
import { SentimentGauge } from './SentimentGauge';
import { SentimentMatrix } from './SentimentMatrix';
import { formatScore, sideColor } from './sentimentKit';
import './SentimentTab.css';

const isEmpty = (data: SentimentOverview) => data.analyzed === 0;

function DivergingBar({ score, color, label }: { score: number; color: string; label: string }) {
  const width = `${Math.min(1, Math.abs(score)) * 50}%`;
  return (
    <span className="diverging" role="img" aria-label={`${label}: ${formatScore(score)}`}>
      <span className="diverging__track">
        <span
          className="diverging__bar"
          style={{
            width,
            background: color,
            insetInlineStart: score >= 0 ? '50%' : `calc(50% - ${width})`,
          }}
        />
      </span>
      <span className="diverging__value">{formatScore(score)}</span>
    </span>
  );
}

function GaugesPanel({ data }: { data: SentimentOverview }) {
  return (
    <div className="sentiment-tab__gauges">
      <Panel>
        <SentimentGauge title="احساس مشتریان" split={data.customer} color={sideColor.customer} />
      </Panel>
      <Panel>
        <SentimentGauge title="احساس اپراتورها" split={data.agent} color={sideColor.agent} />
      </Panel>
    </div>
  );
}

// function JourneyPanel({ journey }: { journey: SentimentOverview['journey'] }) {
//   const total = journey.improved + journey.unchanged + journey.worsened;
//   const steps = [
//     { key: 'improved', label: 'بهتر شد', arrow: '↗', count: journey.improved },
//     { key: 'unchanged', label: 'تغییری نکرد', arrow: '→', count: journey.unchanged },
//     { key: 'worsened', label: 'بدتر شد', arrow: '↘', count: journey.worsened },
//   ] as const;
//   return (
//     <Panel title="سفر احساس مشتری — از ابتدا تا پایان مکالمه">
//       <div className="journey">
//         <div className="journey__source">
//           <strong>{formatPersianNumber(total)}</strong>
//           <span>مکالمه تحلیل‌شده</span>
//         </div>
//         <ul className="journey__flows">
//           {steps.map((step) => {
//             const share = total ? step.count / total : 0;
//             return (
//               <li key={step.key} className={`journey__flow journey__flow--${step.key}`}>
//                 <span
//                   className="journey__ribbon"
//                   style={{ width: `${Math.max(share, 0.04) * 100}%` }}
//                 />
//                 <span className="journey__label">
//                   <span className="journey__arrow" aria-hidden="true">
//                     {step.arrow}
//                   </span>
//                   {step.label}
//                 </span>
//                 <span className="journey__figure">
//                   <strong>{formatPercent(share)}</strong>
//                   <small>{formatPersianNumber(step.count)}</small>
//                 </span>
//               </li>
//             );
//           })}
//         </ul>
//       </div>
//     </Panel>
//   );
// }

// function MatrixPanel() {
//   const scope = useDashboardScope();
//   const toggle = useDashboardFilterStore((state) => state.toggle);
//   const query = useSentimentOverview(scopeForChart(scope, 'sentiment'));
//   return (
//     <Panel title="ماتریس احساس مشتری × اپراتور">
//       <ChartState query={query} isEmpty={isEmpty} skeletonRows={4}>
//         {(data) => (
//           <SentimentMatrix
//             matrix={data.matrix}
//             selected={scope.filters.sentiment}
//             onSelect={(value) => toggle('sentiment', value)}
//           />
//         )}
//       </ChartState>
//     </Panel>
//   );
// }

export function CustomerFacesPanel() {
  const scope = useDashboardScope();
  const toggle = useDashboardFilterStore((state) => state.toggle);
  const query = useSentimentOverview(scopeForChart(scope, 'sentimentLevel'));
  return (
    <Panel title="احساس مشتریان در یک نگاه">
      <ChartState query={query} isEmpty={isEmpty} skeletonRows={3}>
        {(data) => (
          <CustomerSentimentFaces
            rows={data.customerLevels}
            score={data.customerScore}
            analyzed={data.analyzed}
            selected={scope.filters.sentimentLevel}
            onSelect={(value) => toggle('sentimentLevel', value)}
          />
        )}
      </ChartState>
    </Panel>
  );
}

function SubjectButterfly({ rows }: { rows: SentimentOverview['bySubject'] }) {
  const scope = useDashboardScope();
  const toggle = useDashboardFilterStore((state) => state.toggle);
  const selected = scope.filters.subject1;
  return (
    <Panel title="احساس دو طرف به تفکیک موضوع اصلی">
      <div className="butterfly">
        <div className="butterfly__head" aria-hidden="true">
          <span>موضوع</span>
          <span>مشتری</span>
          <span>اپراتور</span>
        </div>
        {rows.map((row) => (
          <button
            key={row.subject}
            type="button"
            className={cn(
              'butterfly__row',
              selected !== undefined && selected !== row.subject && 'butterfly__row--dimmed',
            )}
            aria-pressed={selected === row.subject}
            onClick={() => toggle('subject1', row.subject)}
          >
            <span className="butterfly__label">
              {row.subject}
              <small>{formatPersianNumber(row.count)} تماس</small>
            </span>
            <DivergingBar score={row.customerScore} color={sideColor.customer} label="مشتری" />
            <DivergingBar score={row.agentScore} color={sideColor.agent} label="اپراتور" />
          </button>
        ))}
      </div>
    </Panel>
  );
}

function OperatorSentimentPanel({ rows }: { rows: SentimentOverview['byOperator'] }) {
  const scope = useDashboardScope();
  const toggle = useDashboardFilterStore((state) => state.toggle);
  const selected = scope.filters.operator;
  return (
    <Panel title="احساس به تفکیک اپراتور">
      <div className="butterfly">
        <div className="butterfly__head butterfly__head--operators" aria-hidden="true">
          <span>اپراتور</span>
          <span>مشتری</span>
          <span>لحن اپراتور</span>
          <span>بهبود حال مشتری</span>
        </div>
        {rows.map((row) => (
          <button
            key={row.operator}
            type="button"
            className={cn(
              'butterfly__row butterfly__row--operators',
              selected !== undefined && selected !== row.operator && 'butterfly__row--dimmed',
            )}
            aria-pressed={selected === row.operator}
            onClick={() => toggle('operator', row.operator)}
          >
            <span className="butterfly__label">
              {row.operator}
              <small>{formatPersianNumber(row.count)} تماس</small>
            </span>
            <DivergingBar score={row.customerScore} color={sideColor.customer} label="مشتری" />
            <DivergingBar score={row.agentScore} color={sideColor.agent} label="اپراتور" />
            <span
              className="butterfly__meter"
              aria-label={`بهبود حال مشتری: ${formatPercent(row.improvedShare)}`}
            >
              <span className="butterfly__meter-track">
                <span style={{ width: `${row.improvedShare * 100}%` }} />
              </span>
              {formatPercent(row.improvedShare)}
            </span>
          </button>
        ))}
      </div>
    </Panel>
  );
}

export function SentimentTab() {
  const scope = useDashboardScope();
  const query = useSentimentOverview(scope);
  return (
    <ChartState query={query} isEmpty={isEmpty} skeletonRows={8}>
      {(data) => (
        <div className="dashboard__section">
          <GaugesPanel data={data} />
          <div className="dashboard__grid dashboard__grid--wide">
            {/* <JourneyPanel journey={data.journey} /> */}
            {/* <MatrixPanel /> */}
          </div>
          <div className="dashboard__grid dashboard__grid--wide">
            <SubjectButterfly rows={data.bySubject} />
            <OperatorSentimentPanel rows={data.byOperator} />
          </div>
        </div>
      )}
    </ChartState>
  );
}
