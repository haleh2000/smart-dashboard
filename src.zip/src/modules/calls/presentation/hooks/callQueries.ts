import { useEffect } from 'react';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { SubjectPath } from '@/shared/domain/insights';
import type { CallFilter, CallQuery } from '../../domain/CallRepository';
import { subscribeToCallFeed } from '../../domain/callFeed';
import { useCallRepository } from '../callServices';

export const callKeys = {
  all: ['calls'] as const,
  lists: () => [...callKeys.all, 'list'] as const,
  list: (query: CallQuery) => [...callKeys.lists(), query] as const,
  summary: (filter: CallFilter) => [...callKeys.lists(), 'summary', filter] as const,
  detail: (id: string) => [...callKeys.all, 'detail', id] as const,
  filterOptions: () => [...callKeys.all, 'filterOptions'] as const,
  subjectTree: () => [...callKeys.all, 'subjectTree'] as const,
};

/** Live path: a push on the feed refetches the call table and its summary without a reload. */
function useLiveCalls() {
  const queryClient = useQueryClient();
  useEffect(
    () => subscribeToCallFeed(() => queryClient.invalidateQueries({ queryKey: callKeys.lists() })),
    [queryClient],
  );
}

export function useCalls(query: CallQuery) {
  const repository = useCallRepository();
  useLiveCalls();
  return useQuery({
    queryKey: callKeys.list(query),
    queryFn: () => repository.list(query),
    placeholderData: keepPreviousData,
  });
}

export function useCallSummary(filter: CallFilter) {
  const repository = useCallRepository();
  useLiveCalls();
  return useQuery({
    queryKey: callKeys.summary(filter),
    queryFn: () => repository.summarize(filter),
    placeholderData: keepPreviousData,
  });
}

export function useCall(id: string) {
  const repository = useCallRepository();
  return useQuery({ queryKey: callKeys.detail(id), queryFn: () => repository.getById(id) });
}

export function useCallFilterOptions() {
  const repository = useCallRepository();
  return useQuery({
    queryKey: callKeys.filterOptions(),
    queryFn: () => repository.getFilterOptions(),
    staleTime: 5 * 60_000,
  });
}

export function useSubjectTree() {
  const repository = useCallRepository();
  return useQuery({
    queryKey: callKeys.subjectTree(),
    queryFn: () => repository.getSubjectTree(),
    staleTime: Infinity,
  });
}

/** Saves the 3-level categorization; the detail cache is updated, lists are refetched. */
export function useCategorizeCall() {
  const repository = useCallRepository();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, subject }: { id: string; subject: SubjectPath }) =>
      repository.categorize(id, subject),
    onSuccess: (call) => {
      queryClient.setQueryData(callKeys.detail(call.id), call);
      void queryClient.invalidateQueries({ queryKey: callKeys.lists() });
    },
  });
}
